# LCMS
## Sampling tool

Python script untuk melakukan proses pengambilan sampel penutup lahan dalam rangka mendukung inisiatif land cover monitoring system.
